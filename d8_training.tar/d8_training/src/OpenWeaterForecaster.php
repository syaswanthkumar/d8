<?php

namespace Drupal\d8_training;

use Drupal\Core\Config\ConfigFactory;
use GuzzleHttp\Client;
use Drupal\Component\Serialization\Json;

class OpenWeaterForecaster{

	private $config_factory;
	
	protected $app_id;

	public function __construct(ConfigFactory $config_factory, Client $http){
		$this->config_factory = $config_factory;
		$this->http = $http;

	}

	public function fetchWeatherData($city){
		$this->app_id = $this->config_factory->get('d8_training.configform')->get('app_id');
		$args[] = "http://api.openweathermap.org/data/2.5/weather?q=" . $city . "&appid=" . $this->app_id;
		$method = "GET";

		$request = $this->http->__call($method, $args);
		$response = $request->getBody();
		$data = $response->getContents();
		$final_array = Json::decode($data,TRUE);
		
		return $final_array;
	}


  
}
