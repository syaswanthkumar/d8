<?php

namespace Drupal\d8_training\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Database\Driver\mysql\Connection;

/**
 * Provides a 'CustomNodeLists' block.
 *
 * @Block(
 *  id = "custom_node_lists",
 *  admin_label = @Translation("Custom node lists"),
 * )
 */
class CustomNodeLists extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * Drupal\Core\Database\Driver\mysql\Connection definition.
   *
   * @var Drupal\Core\Database\Driver\mysql\Connection
   */
  protected $database;
  /**
   * Construct.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param string $plugin_definition
   *   The plugin implementation definition.
   */
  public function __construct(
        array $configuration,
        $plugin_id,
        $plugin_definition,
        Connection $database
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->database = $database;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('database')
    );
  }



  /**
   * {@inheritdoc}
   */
  public function build() {
    $build = [];
    

    $query = $this->database->select('node','n');
    $query->join('node_field_data','nfd','n.nid = nfd.nid AND n.vid = nfd.vid');
    $query->addField('nfd','title');
    $query->addField('nfd','nid');
    $query->orderBy('nfd.created','DESC');
    $query->range(0,3);
    $result = $query->execute()->fetchAll();
    
    $output= "";
    $node_tags = array();
    foreach ($result as $key => $value) { 
      $output = ($output!='')?$output." | ".$value->title:$value->title;
      $node_tags[] = 'node:'.$value->nid;
    }
    $build['custom_node_lists']['#markup'] = $output;
    $build['custom_node_lists']['#cache'] = array(
      'tags' => $node_tags
    );

    return $build;
  }

}
