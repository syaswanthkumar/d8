<?php

namespace Drupal\d8_training\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'NodeTitleBlock' block.
 *
 * @Block(
 *  id = "node_title_block",
 *  admin_label = @Translation("Node title block"),
 * )
 */
class NodeTitleBlock extends BlockBase {


  /**
   * {@inheritdoc}
   */
  public function build() {
    $build = [];
    $build['node_title_block']['#markup'] = 'Implement NodeTitleBlock.';

    return $build;
  }

}
