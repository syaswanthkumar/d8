<?php

namespace Drupal\d8_training\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\d8_training\OpenWeaterForecaster;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;

/**
 * Provides a 'WeatherBlock' block.
 *
 * @Block(
 *  id = "weather_block",
 *  admin_label = @Translation("Weather block"),
 * )
 */
class WeatherBlock extends BlockBase implements ContainerFactoryPluginInterface{
  
  /**
   * {@inheritdoc}
   */
  private $owf;
  public function __construct(array $configuration, $plugin_id, $plugin_definition, OpenWeaterForecaster $owf){
  	parent::__construct($configuration, $plugin_id, $plugin_definition);	
  	$this->owf = $owf;
  }
  public function blockForm($form, FormStateInterface $form_state) {
    $form['city_name'] = array(
    	'#type' => 'textfield',
    	'#title' => t('City Name'),
    	'#default_value' => $this->configuration['city_name'],
    );
    return $form;
  }

  public function build(){
  	return array(
  		'#theme' => 'weather_data',
  		'#weather_data' => $this->owf->fetchWeatherData($this->configuration['city_name']),
  		'#attached' => array(
  			'library' => ['d8_training/weather-widget']
  		 )
  	);
  }

  public function blockSubmit($form, FormStateInterface $form_state){
  	$this->configuration['city_name'] = $form_state->getValue('city_name');
  }

  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
		return new static(
			$configuration,
			$plugin_id,
			$plugin_definition,
			$container->get('d8_training.openweatherforecaster')
		);
	}
}
