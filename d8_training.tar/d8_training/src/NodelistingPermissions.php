<?php

namespace Drupal\d8_training;


use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\NodeType;
/**
 * Class pageController.
 *
 * @package Drupal\mymodule\Controller
 */
class NodelistingPermissions extends ControllerBase {

  public function getPermissions(){
    $types = NodeType::loadMultiple();

    $premissions = [];
    foreach($types as $type):
      $permissions['access Training Programme for content-type' . strtolower($type->get('name'))] = array(
        'title' => 'Access Training Programme for content type ::' . $type->get('name')
      );
    endforeach;
    
    return $permissions;
  }

}
