<?php

namespace Drupal\d8_training\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\FormInterface;
use Drupal\Core\Database\Driver\mysql\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\d8_training\FormManager;


class SimpleForm extends FormBase{

	private $connection;

	public function __construct(FormManager $form_manager){
  		$this->connection = $form_manager;
  	}

	public function getFormId() {
		return 'training_form';
	}

	public function buildForm(array $form, FormStateInterface $form_state) {

		$form['first_name'] = array(
			'#type' => 'textfield',
			'#title' =>t('First Name')
		);
		$form['last_name'] = array(
			'#type' => 'textfield',
			'#title' =>t('Last Name')
		);

		$form['Submit'] = array(
			'#type' => 'submit',
			'#value' => t('Submit')
		);

		return $form;
	}
	public function validateForm(array &$form, FormStateInterface $form_state) { 
		$values = $form_state->getValues();
		$first_name = $values['first_name'];
		if(strlen($first_name)<5){
			$form_state->setError($form['first_name'],t('Please enter minimum 5 charecters'));
		}
	}

	public static function create(ContainerInterface $containerinterface) {
		return new static(
			$containerinterface->get('d8_training.form_manager')
		);
	}

	public function submitForm(array &$form, FormStateInterface $form_state){
		$values = $form_state->getValues();
		$first_name = $values['first_name'];
		$last_name = $values['last_name'];
		$data = array('first_name'=>$first_name,'last_name'=>$last_name);
		$this->connection->addData($data);
		
	}
}
