<?php

namespace Drupal\d8_training;

use Drupal\Core\Database\Driver\mysql\Connection;

class FormManager {

 private $connection;

 public function __construct($connection){
  $this->connection = $connection;
 }

 public function fetchData(){

  $query = $this->connection->select('simple_form','sf`');
  $query->fields('sf',array());
  $query->range(0,1);
  $result = $query->execute()->fetchAssoc();
  return $result['first_name'];

 }

 public function addData($data){
  $query = $this->connection->insert('simple_form')
          ->fields(array('first_name'=>$data['first_name'],'last_name'=>$data['last_name']));
  $query->execute();
 }
  
}
