<?php

namespace Drupal\d8_training\Controller;


use Drupal\Core\Controller\ControllerBase;
use Drupal\node\NodeInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Database\Driver\mysql\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;
/**
 * Class pageController.
 *
 * @package Drupal\mymodule\Controller
 */
class NodelistingController extends ControllerBase {

  private $connection;

  public function __construct(Connection $connection){
  	$this->connection = $connection;
  }

  public static function create(ContainerInterface $container){
  	return new static(
  		$container->get('database')
  		//$container->get('logger.dblog')
  	);
  }

  public function content() {
  	$query = $this->connection->select('node','n')
  	->fields('n');
  	$result = $query->execute()->fetchAll();
  	$rows = array();
  	foreach($result as $items):
  		$rows[] = array($items->nid,$items->type);
  	endforeach;

  	$headers = array('NodeID','type');

	return array(
      '#theme' => 'table',
      '#rows' => $rows,
      '#header'=> $headers,
      '#empty' => t('No records found')
    );
  }

  public function dynamiclist($name) {
    return [
      '#type' => 'markup',
      '#markup' => $name,
    ];
  }

  public function dynamicobjectlist(NodeInterface $node){
  	$data = array('title'=>$node->getTitle());
  	return new JsonResponse($data);
  }

}
