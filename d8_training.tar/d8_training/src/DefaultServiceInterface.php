<?php

namespace Drupal\d8_training;

/**
 * Interface DefaultServiceInterface.
 *
 * @package Drupal\d8_training
 */
interface DefaultServiceInterface {


}
