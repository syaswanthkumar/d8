<?php

namespace Drupal\d8_training;


/**
 * Class DefaultService.
 *
 * @package Drupal\d8_training
 */
class DefaultService implements DefaultServiceInterface {
  /**
   * Constructor.
   */
  public function __construct() {

  }

}
